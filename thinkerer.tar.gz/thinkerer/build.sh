bazel build //thinkerer:all //checker:all
