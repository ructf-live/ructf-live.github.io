while true; do
	LD_LIBRARY_PATH=/usr/local/lib ./lifesim $1 1234 4321
done
